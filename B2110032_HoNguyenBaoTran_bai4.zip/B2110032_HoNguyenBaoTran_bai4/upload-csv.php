<!DOCTYPE html>
<html lang="en">
<body>
    <form action="upload-csv-processing.php" method="post" enctype="multipart/form-data">
        Chon 1 tap tin de upload: <input type="file" name="file">
        <input type="submit" value="Submit">
    </form>
</body>
</html>